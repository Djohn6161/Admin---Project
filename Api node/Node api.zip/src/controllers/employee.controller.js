const EmployeeModel = require('../models/employee.model');
//get all employee list
exports.getEmployeeList = (req, res) => {
    //console.log('here all employees list');
    EmployeeModel.getAllEmployees((err, employees) =>{
        console.log('We are here');
        if(err)
            res.send(err);
        console.log('Employees', employees);
        res.send(employees);
    })
}
//get employee by ID
exports.getEmployeeByID = (req, res)=>{
    //console.log(`get employee by ID ${req.params.id}`);
    EmployeeModel.getEmployeeByID((req.params.id, (err, employee)=>{
        if(err)
            res.send(err);
        console.log('Single employee data', employee);
        res.send(employee);
    }))
}