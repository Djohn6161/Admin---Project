const express = require('express');

//create express app
const app = express();

//setup the server port
const port = process.env.PORT || 5000;

// import employee
const employeeRoutes = require('./src/routes/employee.route');

//create employee routes
app.use('/api/v1/employee', employeeRoutes);

// define root server
app.get ('/', (req, res) =>{
    res.send('Hello World');
});

//listen to the port
app.listen(port, ()=>{
    console.log(`Server is running at port ${port}`);
});